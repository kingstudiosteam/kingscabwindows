The King's Cab - Professional Impulse Response Loader

INSTALLATION LOCATIONS:
• VST3: /Library/Audio/Plug-Ins/VST3/
• AU: /Library/Audio/Plug-Ins/Components/
• AAX: /Library/Application Support/Avid/Audio/Plug-Ins/

COMPATIBILITY:
• macOS 10.13 or later
• Intel and Apple Silicon Macs
• 64-bit DAWs only

AFTER INSTALLATION:
1. Restart your DAW
2. Look for "The King's Cab" in your plugin list
3. Load your premium IR collection from the designated folder

For support and premium IR collections:
https://www.kingstudiospa.com/store

© King Studios - All rights reserved
